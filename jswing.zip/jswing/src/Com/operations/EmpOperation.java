package Com.operations;

public interface EmpOperation {

	
	void addEmp(Emp emp);
	
	void updateEmp(Emp emp);

	void deleteEmp(Emp emp);

	void searchEmp();

	void showEmp();

	

	

}
