package Com.operations;

import java.sql.PreparedStatement;
import java.sql.SQLException;

import Com.connector.GetConnection;



public class Implementations implements EmpOperation{

	@Override
	public void addEmp( Emp emp) {
		PreparedStatement preparedStatement;
		try {
			
			preparedStatement = preparedStatement = GetConnection.getConnection().prepareStatement("INSERT INTO `emp` (`id`, `name`, `salary`, `address`) VALUES (?,?,?,?)" );
			preparedStatement.setInt(1, emp.getId());
			preparedStatement.setString(2, emp.getName() );
			preparedStatement.setDouble(3, emp.getSalary());
			preparedStatement.setString(4, emp.getAddress());
			preparedStatement.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public void updateEmp( Emp emp) {
		// TODO Auto-generated method stub
		PreparedStatement preparedStatement;
		try {
			
			preparedStatement = preparedStatement = GetConnection.getConnection().prepareStatement("update emp set name=? where id=?" );
			preparedStatement.setString(1, emp.getName() );
			preparedStatement.setInt(2, emp.getId());
			preparedStatement.setDouble(3, emp.getSalary());
			preparedStatement.setString(4, emp.getAddress());
			preparedStatement.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}


	@Override
	public void deleteEmp(Emp emp) {
		// TODO Auto-generated method stub
	
		try {
			PreparedStatement preparedStatement = GetConnection.getConnection().prepareStatement("delete from emp where id=?");
			preparedStatement.setInt(1, emp.getId());
			preparedStatement.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

	@Override
	public void searchEmp() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void showEmp() {
		// TODO Auto-generated method stub
		
	}

}
