package Com.connector;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


public class GetConnection {

	static Connection connection = null;
	
	public static Connection getConnection() {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	 try {
		connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/swing","root","");
	} catch (SQLException e) {
		e.printStackTrace();
	}
		
		
		return connection;
		
	}

}





